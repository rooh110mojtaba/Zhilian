package butterknife;

public final class R {
    private R() {
    }
}
